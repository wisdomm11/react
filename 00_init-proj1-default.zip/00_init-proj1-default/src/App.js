
function App() {
  return (
    
    <div>
      초기 셋팅 완료 
    </div>

  );
}

export default App;
