
function Main_App2() {
    // 자바 스크립트 변수 선언 블락 
    const name = '리액트';

    return (
    <div>
        {/* JSX 코드 : HTML의 출력 부분 : body  */}
        <hr />
            <h1>{name} 안녕</h1>
            <h2>잘 작동하니?</h2>
        <hr /> 

    </div>); 
}

export default Main_App2; 