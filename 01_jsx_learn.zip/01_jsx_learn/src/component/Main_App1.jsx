// Fragment : JSX 에서 감싼태그를 비우고 출력 
import { Fragment } from "react/jsx-runtime";

function Main_App1() {

    return(
        <Fragment>
            <h2> 메인 의 첫번째 App1 블락 입니다. </h2>
            <h5> 메인 App1 </h5>
        </Fragment>
    );
}

export default Main_App1; 