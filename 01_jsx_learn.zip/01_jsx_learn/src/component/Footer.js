
function Footer() {
        // Java Script 코드 블락 : 변수선언, 상태 선언 


    return (
        <>
            <h1> 푸터 입니다. </h1>
            <hr />
        </>
    ); 
}

// Footer 컴포넌트를 외부에 사용 할 수 있도록 허용 
export default Footer; 