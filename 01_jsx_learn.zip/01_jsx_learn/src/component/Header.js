// Header 컴포넌트 

function Header(){
    // 자바 스크립트 코드 블락

    return (
        <div>
            {/*  JSX 코드 블락  */}
            <h1> 헤더 컴포넌트 입니다.</h1>
            <hr /> 
        </div>
    ); 
}

export default Header; 