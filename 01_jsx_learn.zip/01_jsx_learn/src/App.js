// 자바스크립트 한줄 주석 : App.js   
//       <== 컴포넌트 : 자주 사용하는 코드를 재사용 하기 위해 만듬. (html,css,js)
//                   영문 첫자 대문자 시작, 확장자 : js, jsx 

// 외부의 컴포넌트를 불러 들인다. 
import Header from "./component/Header";
import Footer from "./component/Footer";
import Main_App1 from "./component/Main_App1";
import Main_App2 from "./component/Main_App2";

function App() {
     // Java Script 코드 

  return (
    <div>
      {/* JSX : 코드 블락에서 주석 */}
      <Header />
      <Main_App1 /> 
      <Main_App2 />
        <b>
        초기 셋팅 완료 
        </b>
      <Footer />

    </div>

  );
}

export default App;
