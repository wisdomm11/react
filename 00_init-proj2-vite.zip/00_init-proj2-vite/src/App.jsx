
function App() {

  return (
    <>
        초기 셋팅 완료
    </>
  )
}

export default App
